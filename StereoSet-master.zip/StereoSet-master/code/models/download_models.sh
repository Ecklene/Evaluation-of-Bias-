mkdir pretrained_models
wget -P pretrained_models http://moinnadeem.com/stereoset/pretrained_models/GPT2Model_gpt2_0.0005.pth
wget -P pretrained_models http://moinnadeem.com/stereoset/pretrained_models/GPT2Model_gpt2-medium_0.0005.pth
wget -P pretrained_models http://moinnadeem.com/stereoset/pretrained_models/GPT2Model_gpt2-large_1e-05.pth
wget -P pretrained_models http://moinnadeem.com/stereoset/pretrained_models/XLNetModel_xlnet-base-cased_1e-05.pth
wget -P pretrained_models http://moinnadeem.com/stereoset/pretrained_models/XLNetModel_xlnet-large-cased_1e-05.pth
wget -P pretrained_models http://moinnadeem.com/stereoset/pretrained_models/RobertaModel_roberta-base_1e-05.pth
wget -P pretrained_models http://moinnadeem.com/stereoset/pretrained_models/RobertaModel_roberta-large_1e-05.pth
wget -P pretrained_models http://moinnadeem.com/stereoset/pretrained_models/SentimentBert.pth
